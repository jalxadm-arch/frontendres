#!/bin/bash
npm run build
node server.js
